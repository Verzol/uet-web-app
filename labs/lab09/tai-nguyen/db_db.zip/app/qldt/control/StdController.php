<?php
    namespace qldt\control;
    require_once("app/qldt/model/Std.php");
    
    
    class StdController {
        public function proc($arr) {
			$std = new \qldt\model\Std();
            $data = $std->getAll();
			return array("status" => "OK", "data" => $data);
        }

		public function getById($arr) {
			$std = new \qldt\model\Std();
            $data = $std->getById($arr[0]);
			return array("status" => "OK", "data" => $data);
        }
		
		public function addStd($arr) {
			$input = json_decode(file_get_contents("php://input"), true);
			$std = new \qldt\model\Std();
			$c = $std->add($input["masv"], $input["hoten"], $input["ngaysinh"], $input["quequan"]);
			return array("status" => "OK", "data" => $c);
        } 
	
		public function delStd($arr) {
			$std = new \qldt\model\Std();
            $c = $std->del($arr[0]);
			return array("status" => "OK", "data" => $c);
        }

        public function updateStd($arr) {
			$input = json_decode(file_get_contents("php://input"), true);
			$std = new \qldt\model\Std();
			$c = $std->update($input["masv"], $input["hoten"], $input["ngaysinh"], $input["quequan"]);
			return array("status" => "OK", "data" => $c);
        }  
    }

<?php
	// Tệp app/core/control/Router.php
    namespace core\control;
    require_once("routes.inc");
    
    
    
    class Router {
		/*
			Input: HTTP method + RESTful URL in request
				   $routes
			Output: ret = ["module", "controller", "action", [parameters]]
		*/
		
        public static function proc() {
        	global $routes;
        	
			$ret = array();

			//Mặc định
			$ret["moduleName"]  = "fallback";		
			$ret["controllerName"]  = "fallback";	
			$ret["actionName"]  = "proc";	
			$ret["parameters"]  = array();
			

			// Tách URI
			$requestURI = explode('/', strtolower($_SERVER['REQUEST_URI']));
			$scriptName = explode('/', strtolower($_SERVER['SCRIPT_NAME']));
			$commandArray = array_diff_assoc($requestURI, $scriptName);
			$commandArray = array_values($commandArray);
			
			$c = count($commandArray);
			
			// Tìm đường
			foreach ($routes as $v) {
				if (strtoupper($v[0]) == $_SERVER["REQUEST_METHOD"]) {
					$uri = explode('/', strtolower($v[1]));
					array_shift($uri);
					if (count($uri) == $c) {
						$i = 0;
						$p = array();
						for (; $i < $c; $i++) {
							if ($commandArray[$i] == $uri[$i]) {
								//static element in path
								//okie, do nothing
							} else if (preg_match('/^{.*}$/', $uri[$i])) {
								//parameters in path
								$p[] = $commandArray[$i];
							} else { 
								break;
							}
						}
						if ($i == $c) {
							//path found
							
							$r = explode('.', strtolower($v[2]));
							
							$ret["moduleName"]  = $r[0];		
							$ret["controllerName"]  = $r[1];
							$ret["actionName"]  = $r[2];
							$ret["parameters"]  = $p;	
							
							break;
						}
					}
				}
			}
	
				
			return $ret;
        }
    }

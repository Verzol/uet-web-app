-- phpMyAdmin SQL Dump
-- version 4.6.6deb5ubuntu0.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 27, 2020 at 02:44 PM
-- Server version: 5.7.32-0ubuntu0.18.04.1
-- PHP Version: 7.2.24-0ubuntu0.18.04.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `QLDT`
--

-- --------------------------------------------------------

--
-- Table structure for table `lop`
--

CREATE TABLE `lop` (
  `malop` varchar(10) COLLATE utf8_bin NOT NULL,
  `tenlop` varchar(45) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `lop`
--

INSERT INTO `lop` (`malop`, `tenlop`) VALUES
('311mk', 'Marketing 311'),
('311pr', 'Quan he cong chung 311'),
('312mk', 'MARKETING 312'),
('312pr', 'Quan he cong chung 312'),
('313mk', 'Marketing 313'),
('510cnt', 'DH CNTT 510 113434'),
('511cnt', 'DH CNTT 510'),
('511cnt32', ''),
('511kt', 'Kinh te 511'),
('511pr', 'Quan he cong chung 511'),
('512kt', 'Kinh te 512'),
('512mk', 'Marketing 512'),
('512pr', 'Quan he cong chung 512'),
('asa', 'AS'),
('dsddsd', 'DSSD1313'),
('dss', 'SDS 13131'),
('fddf', ''),
('fdf', 'fdfd'),
('fdsads', 'SDSAD'),
('sdsdsd', 'DSADAD DSD SSDSDSD DSD'),
('ssadsad', 'SADSDSDSA SDSDS'),
('xxx2', 'CONTEST'),
('zxzxzxz', 'ADSADADS');

-- --------------------------------------------------------

--
-- Table structure for table `nsd`
--

CREATE TABLE `nsd` (
  `tsd` varchar(30) COLLATE utf8_bin NOT NULL,
  `mk` varchar(250) COLLATE utf8_bin NOT NULL,
  `ht` varchar(255) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `nsd`
--

INSERT INTO `nsd` (`tsd`, `mk`, `ht`) VALUES
('3525', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('a', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('a1', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('a12', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('abc', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('abc123', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('abc1234', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('abc12345', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('abc123456', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('b', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('cmc', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('cndjhfd', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('dha', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('dothuhang', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('ds', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('halong2017', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('hbu', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('hdfjd', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('hoang', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('hoangtuan', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('hssd', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('minh', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('nguyenudcminh', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('ntn', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('rawta', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('rrrr', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('sds', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('sdsd', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('sdsdsd', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('sgqg', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('tey', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('user', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh'),
('y3', '*6181AF09B08DF41A9B642B0FDDECB769725C6B03', 'Hoang Minh');

-- --------------------------------------------------------

--
-- Table structure for table `sinhvien`
--

CREATE TABLE `sinhvien` (
  `masv` varchar(20) COLLATE utf8_bin NOT NULL,
  `hoten` varchar(200) COLLATE utf8_bin NOT NULL,
  `ngaysinh` date DEFAULT NULL,
  `gioitinh` tinyint(4) DEFAULT NULL,
  `quequan` varchar(300) COLLATE utf8_bin DEFAULT NULL,
  `malop` varchar(10) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `sinhvien`
--

INSERT INTO `sinhvien` (`masv`, `hoten`, `ngaysinh`, `gioitinh`, `quequan`, `malop`) VALUES
('12312211', 'Nguyá»…n Thanh', '2020-02-20', NULL, 'ThÃ¡i BÃ¬nh', NULL),
('123456', 'Tráº§n Minh QuÃ¢n', '2002-02-22', NULL, 'Nam Äá»‹nh', NULL),
('12345673', 'Tráº§n Tiáº¿n QuÃ¢n', '2002-02-22', NULL, 'Ninh BÃ¬nh', NULL),
('12345678', 'Tráº§n Tiáº¿n QuÃ¢n', '2000-02-22', NULL, 'Báº¯c Giang', NULL),
('12456311', 'Nguyá»…n Tráº§n VÅ©', '1992-10-23', NULL, 'Thanh HÃ³a', NULL),
('45698215', 'Nguyá»…n Thanh HÃ¹ng', '2002-02-20', NULL, 'Háº£i PhÃ²ng', NULL),
('45698216', 'Nguyá»…n Thanh HÃ¹ng', '2002-02-20', NULL, 'Láº¡ng SÆ¡n', NULL),
('45698217', 'Nguyá»…n Thanh TÃ¹ng', '2002-02-20', NULL, 'Cao Báº±ng', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `lop`
--
ALTER TABLE `lop`
  ADD PRIMARY KEY (`malop`);

--
-- Indexes for table `nsd`
--
ALTER TABLE `nsd`
  ADD PRIMARY KEY (`tsd`);

--
-- Indexes for table `sinhvien`
--
ALTER TABLE `sinhvien`
  ADD PRIMARY KEY (`masv`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

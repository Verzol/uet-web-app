//
//
// Ẩn tất cả panel
let hideAllPanel = function() {		
	let panels = document.querySelectorAll("div.panel");
	for (let i = 0; i < panels.length; i++) {
		panels[i].classList.add("nodisplay");
	}
};
//
//
// Hiển thị list-panel
let showListPanel = function() {
	hideAllPanel();
	document.querySelector("div.panel-list").classList.remove("nodisplay");
};
//
//
// Hiển thị edit-panel
let showEditPanel = function() {
	hideAllPanel();
	document.querySelector("div.panel-edit").classList.remove("nodisplay");
};
//
//
// Bắt sự kiện kích link Xóa 
let delClick = function (a) {
	a.onclick = function() {
		if(confirm("Thầy/cô chắc chắn xóa sinh viên " + this.parentNode.parentNode.childNodes[2].innerHTML + ", mã số " + this.parentNode.parentNode.childNodes[1].innerHTML)) {
			let msv = this.parentNode.parentNode.childNodes[1].innerHTML;
			fetch("index.php/students/" + msv, {
				method: "DELETE",
				headers: {"Content-Type": "application/json"},
				body: '{"masv":"' + msv + 
				'"}'})
			.then(resp => {
				if (resp.status == 200) {
					resp.json()
					.then(ret => {
						if (ret.status == "OK") { 
							if (ret.data == 1) {
								let tb = this.parentNode.parentNode.parentNode;
								tb.removeChild(a.parentNode.parentNode);
								// Đánh lại số thứ tự trong bảng
								for (let i = 0; i < tb.rows.length; i++)
									tb.rows[i].cells[0].innerHTML = (i+1).toString();
							}
						}
					});
				}
			});
		} else { return false;}
	};
};
//
//
// Bắt sự kiện kích link Sửa 
let ulink = null;
let updateClick = function (a) {
	a.onclick = function() {
		// 
		ulink = this; // lưu tham chiếu link để có thể dùng lại khi người dùng "Chấp nhận"
		// Đưa dữ liệu lên form nhập
		document.querySelector("div.panel-edit h1").innerHTML = "Cập nhật sinh viên";
		document.querySelector("div.panel-edit div.err-submit").innerHTML = "";

		document.querySelector("div.panel-edit span.err-masv").innerHTML = "";
		document.querySelector("div.panel-edit span.err-hoten").innerHTML = "";
		document.querySelector("div.panel-edit span.err-ngaysinh").innerHTML = "";
		document.querySelector("div.panel-edit span.err-quequan").innerHTML = "";
		document.querySelector("div.panel-edit input.masv").disabled = true;
		document.querySelector("div.panel-edit button.edit-submit").disabled = false;


		document.querySelector("div.panel-edit input.mode").value = "update";
		document.querySelector("div.panel-edit input.masv").value = this.parentNode.parentNode.childNodes[1].innerHTML;
		document.querySelector("div.panel-edit input.hoten").value = this.parentNode.parentNode.childNodes[2].innerHTML;
		document.querySelector("div.panel-edit input.ngaysinh").value = this.parentNode.parentNode.childNodes[3].innerHTML;
		document.querySelector("div.panel-edit input.quequan").value = this.parentNode.parentNode.childNodes[4].innerHTML;

		// Hiển thị edit-panel
		showEditPanel();	
	};
};
//
//
// Tạo <tr>
let createNewRow = function(x1, x2, x3, x4, x5) {
	// Tạo <tr> và các <td> mới
	let r = document.createElement("tr");
	let c1 = document.createElement("td");
	let c2 = document.createElement("td");
	let c3 = document.createElement("td");
	let c4 = document.createElement("td");
	let c5 = document.createElement("td");
	let c6 = document.createElement("td");
	let c7 = document.createElement("td");
	r.appendChild(c1);
	r.appendChild(c2);
	r.appendChild(c3);
	r.appendChild(c4);
	r.appendChild(c5);
	r.appendChild(c6);
	r.appendChild(c7);
	// Đặt nội dung cho các <td>
	//c1-c5
	c1.innerHTML = x1;
	c2.innerHTML = x2;
	c3.innerHTML = x3;
	c4.innerHTML = x4;
	c5.innerHTML = x5;
	// c6
	let aupd = document.createElement("a");
	aupd.href = "#";
	aupd.classList.add("update");
	aupd.innerHTML = "Sửa";
	c6.appendChild(aupd);
	updateClick(aupd); // Thêm hàm xử lý sự kiện kích link
	// c7
	let adel = document.createElement("a");
	adel.href = "#";
	adel.classList.add("delete");
	adel.innerHTML = "Xóa";
	c7.appendChild(adel); 
	delClick(adel); // Thêm hàm xử lý sự kiện kích link
	//
	return r;
};
//
//
// XỬ LÝ CÁC SỰ KIỆN
//
//
// Tải trang: Lấy danh sách sinh viên
fetch("index.php/students")
.then(resp => {
	if (resp.status == 200) {
		resp.json()
		.then(ret => {
			if (ret.status == "OK") {
				let tbl = document.querySelector("table.std-list tbody");
				for (let i = 0; i < ret.data.length; i++) {
					let r = createNewRow((i+1).toString(), ret.data[i].masv, ret.data[i].hoten, ret.data[i].ngaysinh, ret.data[i].quequan);
					tbl.appendChild(r);
				}
			} else {
				// Có lỗi xử lý nghiệp vụ
			}
		});
	} else {
		// Có lỗi HTTP
	}
});
//
//
// Người dùng chọn "Thêm mới"
document.querySelector("button.addnew").onclick = function() {
	// reset form nhập
	document.querySelector("div.panel-edit h1").innerHTML = "Thêm mới sinh viên";
	document.querySelector("div.panel-edit div.err-submit").innerHTML = "";
	document.querySelector("div.panel-edit span.err-masv").innerHTML = "";
	document.querySelector("div.panel-edit span.err-hoten").innerHTML = "";
	document.querySelector("div.panel-edit span.err-ngaysinh").innerHTML = "";
	document.querySelector("div.panel-edit span.err-quequan").innerHTML = "";
	document.querySelector("div.panel-edit input.masv").disabled = false;
	document.querySelector("div.panel-edit button.edit-submit").disabled = true;

	document.querySelector("div.panel-edit input.mode").value = "addnew";
	document.querySelector("div.panel-edit input.masv").value = "";
	document.querySelector("div.panel-edit input.hoten").value = "";
	document.querySelector("div.panel-edit input.ngaysinh").value = "";
	document.querySelector("div.panel-edit input.quequan").value = "";
	
	// Hiển thị edit-panel
	showEditPanel();
};
//
//
// Người dùng chọn "Bỏ qua" trên form nhập (thêm mới hoặc chỉnh sửa)
document.querySelector("button.edit-cancel").onclick = function() {
	ulink = null;
	showListPanel();
};
//
//
// Người dùng vừa nhập mã sinh viên xong trên form nhập (thêm mới)
document.querySelector("input.masv").onblur = function() {
	// Kiểm tra mã sinh viên đã tồn tại hay chưa
	// nếu đã tồn tại thì không cho thêm mới
	fetch("index.php/students/" + document.querySelector("input.masv").value)
	.then(resp => {
		if (resp.status == 200) {
			resp.json()
			.then(ret => {
				if (ret.status == "OK") {
					if (ret.data.length > 0) {
						document.querySelector("div.panel-edit span.err-masv").innerHTML = "Mã sinh viên đã tồn tại";
						document.querySelector("button.edit-submit").disabled = true;
				}	else {
						document.querySelector("div.panel-edit span.err-masv").innerHTML = "";
						document.querySelector("button.edit-submit").disabled = false;
					}
				} else {
					// Xử lý lỗi nghiệp vụ
				}
			});
		} else {
			// Xử lý lỗi HTTP
		}
	});
};
//
//
// Người dùng bấm nút "Chấp nhận" trên form nhập (thêm mới hoặc chỉnh sửa)
document.querySelector("button.edit-submit").onclick = function() {
	fetch("index.php/students/" + document.querySelector("input.masv").value, {
		method: (document.querySelector("div.panel-edit input.mode").value == "addnew" ? "POST" : "PUT"),
		headers: {"Content-Type": "application/json"},
		body: '{"masv":"' + document.querySelector("input.masv").value + 
			'","hoten":"' + document.querySelector("input.hoten").value + '", "ngaysinh":"' + document.querySelector("input.ngaysinh").value + '", "quequan":"' + document.querySelector("input.quequan").value + '"}'
	})
	.then(resp => {
		if (resp.status == 200) {
			resp.json()
			.then(ret => {
				if (ret.status == "OK") {
					if (ret.data == 1) {
						if (document.querySelector("div.panel-edit input.mode").value == "addnew") { // Đã thêm được bên backend
							// Đưa bản ghi mới thêm vào đầu bảng
							let r = createNewRow("1", document.querySelector("input.masv").value, document.querySelector("input.hoten").value, document.querySelector("input.ngaysinh").value, document.querySelector("input.quequan").value);
							let tbl = document.querySelector("table.std-list tbody");
							if (tbl.hasChildNodes()) 		tbl.insertBefore(r, tbl.firstChild);
							else tbl.appendChild(r);
							// Đánh lại số thứ tự trong bảng
							for (let i = 0; i < tbl.rows.length; i++)
								tbl.rows[i].cells[0].innerHTML = (i+1).toString();
						} 
						else { // Đã cập nhật thành công bên backend
							// Cập nhật lại dòng ứng với sinh viên được cập nhật
						ulink.parentNode.parentNode.childNodes[2].innerHTML = document.querySelector("input.hoten").value;
ulink.parentNode.parentNode.childNodes[3].innerHTML = document.querySelector("input.ngaysinh").value;
ulink.parentNode.parentNode.childNodes[4].innerHTML = document.querySelector("input.quequan").value;
ulink = null;		
						}

						// Về list-panel
						showListPanel();
					} else {
						// Không thêm/cập nhật được được
						let txt = (document.querySelector("div.panel-edit input.mode").value == "addnew" ? "thêm" : "cập nhật");
						document.querySelector("div.panel-edit div.err-submit").innerHTML = "Xin lỗi, không " + txt + " được sinh viên!";
					}
				} else {
					// Xử lý lỗi nghiệp vụ	
				}
			});
		} else {
			// Xử lý lỗi HTTP
		}
	});
};	 

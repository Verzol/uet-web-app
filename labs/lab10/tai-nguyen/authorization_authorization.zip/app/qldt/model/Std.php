<?php
    namespace qldt\model;
    require_once("app/core/model/PDOData.php");
          
    class Std {
        private $db;
        public function __construct() { $this->db = new \core\model\PDOData();}
        public function __destruct() { $this->db = null;}
	
        public function getAll() {
            return $this->db->doPreparedQuery("select * from sinhvien;", array());
        }
		public function getById($m) {
            return $this->db->doPreparedQuery("select * from sinhvien where masv = ?;", array($m));
        }
		public function add($m, $ht, $ns, $qq) {
            return $this->db->doPreparedSql("insert into sinhvien(masv, hoten, ngaysinh, quequan) values(?, ?, ?, ?);", array($m, $ht, $ns, $qq));
        }
		public function del($m) {
            return $this->db->doPreparedSql("delete from sinhvien where masv = ?;", array($m));
        }
		public function update($m, $ht, $ns, $qq) {
            return $this->db->doPreparedSql("update sinhvien set hoten = ?, ngaysinh = ?, quequan = ? where masv = ?;", array($ht, $ns, $qq, $m));
        }
    }         

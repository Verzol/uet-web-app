<?php
    namespace qldt\control;
    require_once("app/qldt/model/Std.php");
	require_once("app/core/model/Util.php");
	require_once("app/account/model/User.php");
	use \core\model\Util as Util;
	use \account\model\User as User;
    
    
    class StdController {
        public function proc($arr) {
			// Chưa đăng nhập thì từ chối
			if (!isset($_SESSION["tsd"])) 
				return array("status" => "NOK", "data" => "ACCESS-DENIED");

			// Kiểm tra quyền truy cập
			$user = new User();
			$rights = $user->accessRights($_SESSION["tsd"], "SV");
			if (!in_array("READ", $rights, true))
				return array("status" => "NOK", "data" => "ACCESS-DENIED");

			// Lấy danh sách sinh viên
			$std = new \qldt\model\Std();
            $data = $std->getAll();
            return array("status" => "OK", "data" => $data, "rights" => $rights);
        }

		public function getById($arr) {
			// Chưa đăng nhập thì từ chối
			if (!isset($_SESSION["tsd"])) 
				return array("status" => "NOK", "data" => "ACCESS-DENIED");

			// Kiểm tra quyền truy cập
			$user = new User();
			$rights = $user->accessRights($_SESSION["tsd"], "SV");
			if (!in_array("READ", $rights, true))
				return array("status" => "NOK", "data" => "ACCESS-DENIED");

			// Kiểm tra hợp thức dữ liệu vào
			if (Util::isStdCode($arr[0])) {
				// Đầu vào hợp lệ
				$std = new \qldt\model\Std();
		        $data = $std->getById($arr[0]);
				return array("status" => "OK", "data" => $data, "rights" => $rights);
			} else {
				// Đầu vào không hợp lệ
				return array("status" => "NOK", "data" => "INVALID-INPUT");
			}
        }
		
		public function addStd($arr) {	
			// Chưa đăng nhập thì từ chối
			if (!isset($_SESSION["tsd"])) 
				return array("status" => "NOK", "data" => "ACCESS-DENIED");

			// Kiểm tra quyền truy cập
			$user = new User();
			$rights = $user->accessRights($_SESSION["tsd"], "SV");
			if (!in_array("CREATE", $rights, true))
				return array("status" => "NOK", "data" => "ACCESS-DENIED");


			// Kiểm tra hợp thức dữ liệu vào
			$input = json_decode(file_get_contents("php://input"), true);

			// Đầu vào hợp lệ?
			if (Util::isStdCode($input["masv"]) &&
				Util::isVietnameseFullname($input["hoten"]) &&
				Util::isDate($input["ngaysinh"]) &&
				Util::isText($input["quequan"])
			) {
				$std = new \qldt\model\Std();
				// Kiểm tra mã sinh viên đã được sử dụng chưa
				$data = $std->getById($arr[0]);
				// Chưa được sử dụng thì mới thêm
				if (count($data) == 0) {
					$c = $std->add($input["masv"], $input["hoten"], Util::toEnglishDate($input["ngaysinh"]), $input["quequan"]);
					return array("status" => "OK", "data" => $c);
				} else {
					// Mã sinh viên đã được sử dụng rồi
					return array("status" => "NOK", "data" => "STDCODE-HAS-BEEN-USED");
				}
			} else {
				// Đầu vào không hợp lệ
				return array("status" => "NOK", "data" => "INVALID-INPUT");
			}
        } 
	
		public function delStd($arr) {
			$std = new \qldt\model\Std();
            $c = $std->del($arr[0]);
			return array("status" => "OK", "data" => $c);
        }

        public function updateStd($arr) {
			$input = json_decode(file_get_contents("php://input"), true);
			$std = new \qldt\model\Std();
			$c = $std->update($input["masv"], $input["hoten"], $input["ngaysinh"], $input["quequan"]);
			return array("status" => "OK", "data" => $c);
        }  
    }
